<|layout|columns=1 5|

<|sidebar|

<|{selected_scenario}|scenario_selector|>

<|part|render={selected_scenario}|
<|{selected_data_node}|data_node_selector|not display_cycles|>
|>
|>

<|part|class_name=main|

<|navbar|>

<|part|class_name=main|
<|content|>
|>

|>
|>
